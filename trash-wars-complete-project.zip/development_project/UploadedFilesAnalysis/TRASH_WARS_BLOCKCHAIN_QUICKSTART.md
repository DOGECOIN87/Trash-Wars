# 🔗 TRASH WARS - BLOCKCHAIN INTEGRATION QUICK-START

## 📋 Overview

This guide provides step-by-step instructions to replace the simulated blockchain features with real Solana integration.

---

## 🚀 Phase 1: Wallet Connection (Day 1-2)

### 1. Install Dependencies
```bash
npm install @solana/web3.js \
  @solana/wallet-adapter-base \
  @solana/wallet-adapter-react \
  @solana/wallet-adapter-react-ui \
  @solana/wallet-adapter-wallets
```

### 2. Create Wallet Provider

#### src/providers/WalletProvider.tsx
```typescript
import React, { useMemo } from 'react';
import {
  ConnectionProvider,
  WalletProvider as SolanaWalletProvider,
} from '@solana/wallet-adapter-react';
import { WalletModalProvider } from '@solana/wallet-adapter-react-ui';
import {
  PhantomWalletAdapter,
  SolflareWalletAdapter,
  BackpackWalletAdapter,
} from '@solana/wallet-adapter-wallets';
import { clusterApiUrl } from '@solana/web3.js';

// Import CSS
import '@solana/wallet-adapter-react-ui/styles.css';

export const WalletProvider: React.FC<{ children: React.ReactNode }> = ({
  children,
}) => {
  // Use devnet for testing, mainnet-beta for production
  const endpoint = useMemo(
    () => clusterApiUrl('devnet'),
    []
  );

  const wallets = useMemo(
    () => [
      new PhantomWalletAdapter(),
      new SolflareWalletAdapter(),
      new BackpackWalletAdapter(),
    ],
    []
  );

  return (
    <ConnectionProvider endpoint={endpoint}>
      <SolanaWalletProvider wallets={wallets} autoConnect>
        <WalletModalProvider>
          {children}
        </WalletModalProvider>
      </SolanaWalletProvider>
    </ConnectionProvider>
  );
};
```

### 3. Wrap App with Provider

#### src/index.tsx
```typescript
import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';
import { WalletProvider } from './providers/WalletProvider';
import './index.css';

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <WalletProvider>
      <App />
    </WalletProvider>
  </React.StrictMode>
);
```

### 4. Update MainMenu to Use Real Wallet

#### src/components/MainMenu.tsx (replace simulated connection)
```typescript
import { useWallet } from '@solana/wallet-adapter-react';
import { WalletMultiButton } from '@solana/wallet-adapter-react-ui';
import { useConnection } from '@solana/wallet-adapter-react';
import { LAMPORTS_PER_SOL } from '@solana/web3.js';
import { useEffect, useState } from 'react';

const MainMenu: React.FC<MainMenuProps> = ({ ... }) => {
  const { publicKey, connected } = useWallet();
  const { connection } = useConnection();
  const [balance, setBalance] = useState<number>(0);

  // Fetch real balance
  useEffect(() => {
    if (publicKey) {
      connection.getBalance(publicKey).then((lamports) => {
        setBalance(lamports / LAMPORTS_PER_SOL);
      });
    }
  }, [publicKey, connection]);

  // STEP 1: CONNECT - Use WalletMultiButton
  if (step === 'CONNECT') {
    return (
      <div className="flex flex-col items-center gap-8">
        <h1 className="text-6xl font-black">GORBAGANA: TRASH WARS</h1>
        
        {/* Real Wallet Connection */}
        <WalletMultiButton className="!bg-green-500 !text-black !font-bold !px-8 !py-4 !rounded-xl hover:!bg-green-400 !transition-all" />
        
        {connected && publicKey && (
          <div className="text-center">
            <p className="text-green-400">✅ Connected</p>
            <p className="text-sm text-zinc-400">
              {publicKey.toString().slice(0, 4)}...{publicKey.toString().slice(-4)}
            </p>
            <p className="text-lg font-bold">{balance.toFixed(4)} SOL</p>
            <button
              onClick={() => setStep('SETUP')}
              className="mt-4 bg-purple-500 px-6 py-3 rounded-lg"
            >
              Continue →
            </button>
          </div>
        )}
      </div>
    );
  }

  // HUB: Display real balance
  if (step === 'HUB') {
    return (
      <div>
        <div className="text-xl">Balance: {balance.toFixed(4)} SOL</div>
        <div className="text-sm text-zinc-400">
          {publicKey?.toString().slice(0, 4)}...{publicKey?.toString().slice(-4)}
        </div>
        {/* ... rest of hub UI */}
      </div>
    );
  }

  // ... rest of component
};
```

---

## 💰 Phase 2: Smart Contract (Week 1-2)

### 1. Install Anchor
```bash
# Install Anchor CLI
cargo install --git https://github.com/coral-xyz/anchor avm --locked --force
avm install latest
avm use latest

# Install Solana CLI
sh -c "$(curl -sSfL https://release.solana.com/stable/install)"
```

### 2. Initialize Anchor Project
```bash
anchor init trash-wars-contract
cd trash-wars-contract
```

### 3. Smart Contract Code

#### programs/trash-wars-contract/src/lib.rs
```rust
use anchor_lang::prelude::*;

declare_id!("YOUR_PROGRAM_ID_HERE");

#[program]
pub mod trash_wars {
    use super::*;

    pub fn initialize_player(ctx: Context<InitializePlayer>) -> Result<()> {
        let player = &mut ctx.accounts.player_account;
        player.authority = ctx.accounts.authority.key();
        player.total_games = 0;
        player.total_wins = 0;
        player.total_earnings = 0;
        Ok(())
    }

    pub fn place_wager(ctx: Context<PlaceWager>, wager_amount: u64) -> Result<()> {
        require!(wager_amount >= 10_000_000, ErrorCode::WagerTooLow); // Min 0.01 SOL
        require!(wager_amount <= 500_000_000, ErrorCode::WagerTooHigh); // Max 0.5 SOL

        let game_session = &mut ctx.accounts.game_session;
        let player = &mut ctx.accounts.player_account;

        // Transfer SOL to vault
        let cpi_context = CpiContext::new(
            ctx.accounts.system_program.to_account_info(),
            anchor_lang::system_program::Transfer {
                from: ctx.accounts.authority.to_account_info(),
                to: ctx.accounts.vault.to_account_info(),
            },
        );
        anchor_lang::system_program::transfer(cpi_context, wager_amount)?;

        // Initialize game session
        game_session.player = ctx.accounts.authority.key();
        game_session.wager = wager_amount;
        game_session.start_time = Clock::get()?.unix_timestamp;
        game_session.is_active = true;
        game_session.final_mass = 0;

        player.total_games += 1;

        Ok(())
    }

    pub fn record_result(
        ctx: Context<RecordResult>,
        final_mass: u64,
        survived: bool,
    ) -> Result<()> {
        let game_session = &mut ctx.accounts.game_session;
        require!(game_session.is_active, ErrorCode::GameNotActive);

        game_session.final_mass = final_mass;
        game_session.is_active = false;
        game_session.end_time = Clock::get()?.unix_timestamp;

        if survived {
            // Calculate payout: wager * (mass / 500)
            let multiplier = final_mass.checked_div(500).unwrap_or(0);
            let payout = game_session
                .wager
                .checked_mul(multiplier)
                .unwrap_or(game_session.wager);

            // Cap maximum payout at 10x wager
            let max_payout = game_session.wager.checked_mul(10).unwrap();
            let final_payout = payout.min(max_payout);

            // Transfer payout from vault to player
            **ctx.accounts.vault.to_account_info().try_borrow_mut_lamports()? -= final_payout;
            **ctx.accounts.authority.to_account_info().try_borrow_mut_lamports()? += final_payout;

            let player = &mut ctx.accounts.player_account;
            player.total_wins += 1;
            player.total_earnings = player.total_earnings.checked_add(final_payout).unwrap();

            game_session.payout = final_payout;
        }

        Ok(())
    }
}

#[derive(Accounts)]
pub struct InitializePlayer<'info> {
    #[account(
        init,
        payer = authority,
        space = 8 + PlayerAccount::SIZE,
        seeds = [b"player", authority.key().as_ref()],
        bump
    )]
    pub player_account: Account<'info, PlayerAccount>,
    
    #[account(mut)]
    pub authority: Signer<'info>,
    
    pub system_program: Program<'info, System>,
}

#[derive(Accounts)]
pub struct PlaceWager<'info> {
    #[account(
        mut,
        seeds = [b"player", authority.key().as_ref()],
        bump
    )]
    pub player_account: Account<'info, PlayerAccount>,

    #[account(
        init,
        payer = authority,
        space = 8 + GameSession::SIZE,
        seeds = [b"session", authority.key().as_ref(), &Clock::get()?.unix_timestamp.to_le_bytes()],
        bump
    )]
    pub game_session: Account<'info, GameSession>,

    #[account(mut)]
    /// CHECK: Vault PDA
    pub vault: AccountInfo<'info>,

    #[account(mut)]
    pub authority: Signer<'info>,

    pub system_program: Program<'info, System>,
}

#[derive(Accounts)]
pub struct RecordResult<'info> {
    #[account(
        mut,
        seeds = [b"session", authority.key().as_ref(), &game_session.start_time.to_le_bytes()],
        bump
    )]
    pub game_session: Account<'info, GameSession>,

    #[account(
        mut,
        seeds = [b"player", authority.key().as_ref()],
        bump
    )]
    pub player_account: Account<'info, PlayerAccount>,

    #[account(mut)]
    /// CHECK: Vault PDA
    pub vault: AccountInfo<'info>,

    #[account(mut)]
    pub authority: Signer<'info>,
}

#[account]
pub struct PlayerAccount {
    pub authority: Pubkey,
    pub total_games: u64,
    pub total_wins: u64,
    pub total_earnings: u64,
}

impl PlayerAccount {
    pub const SIZE: usize = 32 + 8 + 8 + 8;
}

#[account]
pub struct GameSession {
    pub player: Pubkey,
    pub wager: u64,
    pub start_time: i64,
    pub end_time: i64,
    pub final_mass: u64,
    pub payout: u64,
    pub is_active: bool,
}

impl GameSession {
    pub const SIZE: usize = 32 + 8 + 8 + 8 + 8 + 8 + 1;
}

#[error_code]
pub enum ErrorCode {
    #[msg("Wager amount is too low (min 0.01 SOL)")]
    WagerTooLow,
    #[msg("Wager amount is too high (max 0.5 SOL)")]
    WagerTooHigh,
    #[msg("Game session is not active")]
    GameNotActive,
}
```

### 4. Build & Deploy
```bash
# Build
anchor build

# Get program ID
anchor keys list

# Update Anchor.toml and lib.rs with program ID

# Deploy to devnet
anchor deploy --provider.cluster devnet

# Test
anchor test
```

---

## 🎮 Phase 3: Frontend Integration (Week 2)

### 1. Create Solana Service

#### src/services/solanaService.ts
```typescript
import { 
  Connection, 
  PublicKey, 
  Transaction,
  SystemProgram,
  LAMPORTS_PER_SOL,
} from '@solana/web3.js';
import { Program, AnchorProvider, web3, BN } from '@project-serum/anchor';
import { useWallet, useConnection } from '@solana/wallet-adapter-react';
import idl from '../idl/trash_wars.json'; // Export from Anchor

const PROGRAM_ID = new PublicKey('YOUR_PROGRAM_ID');

export class SolanaService {
  private program: Program;
  private provider: AnchorProvider;

  constructor(connection: Connection, wallet: any) {
    this.provider = new AnchorProvider(connection, wallet, {});
    this.program = new Program(idl as any, PROGRAM_ID, this.provider);
  }

  async initializePlayer(): Promise<string> {
    const [playerPDA] = await PublicKey.findProgramAddress(
      [Buffer.from('player'), this.provider.wallet.publicKey.toBuffer()],
      this.program.programId
    );

    const tx = await this.program.methods
      .initializePlayer()
      .accounts({
        playerAccount: playerPDA,
        authority: this.provider.wallet.publicKey,
        systemProgram: SystemProgram.programId,
      })
      .rpc();

    return tx;
  }

  async placeWager(wagerSol: number): Promise<string> {
    const wagerLamports = Math.floor(wagerSol * LAMPORTS_PER_SOL);
    const timestamp = Math.floor(Date.now() / 1000);

    const [playerPDA] = await PublicKey.findProgramAddress(
      [Buffer.from('player'), this.provider.wallet.publicKey.toBuffer()],
      this.program.programId
    );

    const [sessionPDA] = await PublicKey.findProgramAddress(
      [
        Buffer.from('session'),
        this.provider.wallet.publicKey.toBuffer(),
        Buffer.from(timestamp.toString()),
      ],
      this.program.programId
    );

    const [vaultPDA] = await PublicKey.findProgramAddress(
      [Buffer.from('vault')],
      this.program.programId
    );

    const tx = await this.program.methods
      .placeWager(new BN(wagerLamports))
      .accounts({
        playerAccount: playerPDA,
        gameSession: sessionPDA,
        vault: vaultPDA,
        authority: this.provider.wallet.publicKey,
        systemProgram: SystemProgram.programId,
      })
      .rpc();

    return tx;
  }

  async recordResult(
    finalMass: number,
    survived: boolean,
    sessionTimestamp: number
  ): Promise<string> {
    const [playerPDA] = await PublicKey.findProgramAddress(
      [Buffer.from('player'), this.provider.wallet.publicKey.toBuffer()],
      this.program.programId
    );

    const [sessionPDA] = await PublicKey.findProgramAddress(
      [
        Buffer.from('session'),
        this.provider.wallet.publicKey.toBuffer(),
        Buffer.from(sessionTimestamp.toString()),
      ],
      this.program.programId
    );

    const [vaultPDA] = await PublicKey.findProgramAddress(
      [Buffer.from('vault')],
      this.program.programId
    );
