import React, { useEffect, useState } from 'react';
import { useWallet, useConnection } from '@solana/wallet-adapter-react';
import { WalletMultiButton } from '@solana/wallet-adapter-react-ui';
import { LAMPORTS_PER_SOL } from '@solana/web3.js';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Slider } from '@/components/ui/slider';
import { Input } from '@/components/ui/input';

type MenuStep = 'CONNECT' | 'SETUP' | 'HUB';

interface PlayerSetup {
  name: string;
  color: string;
  wager: number;
}

const COLORS = ['#22c55e', '#ef4444', '#3b82f6', '#eab308', '#a855f7', '#f97316', '#06b6d4', '#ffffff'];

export const MainMenu: React.FC = () => {
  const { publicKey, connected } = useWallet();
  const { connection } = useConnection();
  const [step, setStep] = useState<MenuStep>('CONNECT');
  const [balance, setBalance] = useState<number>(0);
  const [setup, setSetup] = useState<PlayerSetup>({
    name: '',
    color: COLORS[0],
    wager: 0.05,
  });

  // Fetch real balance
  useEffect(() => {
    if (publicKey) {
      connection.getBalance(publicKey).then((lamports) => {
        setBalance(lamports / LAMPORTS_PER_SOL);
      });
    }
  }, [publicKey, connection]);

  // STEP 1: CONNECT
  if (step === 'CONNECT') {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center gap-8 bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 p-4">
        <div className="text-center space-y-4">
          <h1 className="text-6xl font-black text-transparent bg-clip-text bg-gradient-to-r from-green-400 via-blue-400 to-purple-400">
            GORBAGANA
          </h1>
          <h2 className="text-4xl font-bold text-white">TRASH WARS</h2>
          <p className="text-lg text-gray-300">Connect your Solana wallet to begin</p>
        </div>

        <Card className="w-full max-w-md p-8 bg-slate-800/50 border-purple-500/30 backdrop-blur">
          <div className="flex flex-col gap-4">
            <WalletMultiButton className="!bg-green-500 !text-black !font-bold !px-8 !py-4 !rounded-xl hover:!bg-green-400 !transition-all !h-auto" />

            {connected && publicKey && (
              <div className="space-y-4 text-center">
                <div className="p-4 bg-green-500/10 border border-green-500/30 rounded-lg">
                  <p className="text-green-400 font-semibold">✅ Connected</p>
                  <p className="text-sm text-gray-300 mt-2">
                    {publicKey.toString().slice(0, 8)}...{publicKey.toString().slice(-8)}
                  </p>
                  <p className="text-xl font-bold text-white mt-2">{balance.toFixed(4)} SOL</p>
                </div>

                <Button
                  onClick={() => setStep('SETUP')}
                  className="w-full bg-purple-600 hover:bg-purple-700 text-white font-bold py-3 rounded-lg"
                >
                  Continue to Setup →
                </Button>
              </div>
            )}
          </div>
        </Card>
      </div>
    );
  }

  // STEP 2: SETUP
  if (step === 'SETUP') {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center gap-8 bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 p-4">
        <h1 className="text-4xl font-black text-transparent bg-clip-text bg-gradient-to-r from-green-400 via-blue-400 to-purple-400">
          Player Setup
        </h1>

        <Card className="w-full max-w-md p-8 bg-slate-800/50 border-purple-500/30 backdrop-blur space-y-6">
          <div>
            <label className="block text-white font-semibold mb-2">Player Name</label>
            <Input
              type="text"
              placeholder="Enter your name"
              value={setup.name}
              onChange={(e) => setSetup({ ...setup, name: e.target.value })}
              className="bg-slate-700 border-slate-600 text-white placeholder-gray-400"
            />
          </div>

          <div>
            <label className="block text-white font-semibold mb-3">Choose Color</label>
            <div className="grid grid-cols-4 gap-3">
              {COLORS.map((color) => (
                <button
                  key={color}
                  onClick={() => setSetup({ ...setup, color })}
                  className={`w-full aspect-square rounded-lg transition-all ${
                    setup.color === color ? 'ring-2 ring-white scale-110' : ''
                  }`}
                  style={{ backgroundColor: color }}
                />
              ))}
            </div>
          </div>

          <div>
            <label className="block text-white font-semibold mb-2">
              Wager: {setup.wager.toFixed(2)} SOL
            </label>
            <Slider
              value={[setup.wager]}
              onValueChange={(value) => setSetup({ ...setup, wager: value[0] })}
              min={0.01}
              max={0.5}
              step={0.01}
              className="w-full"
            />
            <p className="text-xs text-gray-400 mt-2">Min: 0.01 SOL | Max: 0.5 SOL</p>
          </div>

          <Button
            onClick={() => setStep('HUB')}
            disabled={!setup.name}
            className="w-full bg-green-500 hover:bg-green-600 text-black font-bold py-3 rounded-lg disabled:opacity-50"
          >
            Proceed to Hub →
          </Button>
        </Card>
      </div>
    );
  }

  // STEP 3: HUB
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 p-4">
      <div className="max-w-6xl mx-auto">
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-4xl font-black text-transparent bg-clip-text bg-gradient-to-r from-green-400 via-blue-400 to-purple-400">
              GORBAGANA COMMAND HUB
            </h1>
            <p className="text-gray-300 mt-2">Welcome, {setup.name}</p>
          </div>
          <div className="text-right">
            <p className="text-sm text-gray-400">Balance</p>
            <p className="text-3xl font-bold text-white">{balance.toFixed(4)} SOL</p>
            <p className="text-xs text-gray-400 mt-1">
              {publicKey?.toString().slice(0, 8)}...{publicKey?.toString().slice(-8)}
            </p>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-6">
          <Card className="p-6 bg-slate-800/50 border-purple-500/30 backdrop-blur hover:border-purple-500/60 transition-all cursor-pointer">
            <div className="text-4xl mb-3">🎮</div>
            <h3 className="text-xl font-bold text-white mb-2">DEPLOY</h3>
            <p className="text-gray-300 mb-4">Enter Trash Wars</p>
            <p className="text-sm text-green-400 font-semibold">Wager: {setup.wager.toFixed(2)} SOL</p>
          </Card>

          <Card className="p-6 bg-slate-800/50 border-purple-500/30 backdrop-blur hover:border-purple-500/60 transition-all cursor-pointer">
            <div className="text-4xl mb-3">🎒</div>
            <h3 className="text-xl font-bold text-white mb-2">GORBAG</h3>
            <p className="text-gray-300 mb-4">View Inventory</p>
            <p className="text-sm text-blue-400 font-semibold">[0 Items]</p>
          </Card>

          <Card className="p-6 bg-slate-800/50 border-purple-500/30 backdrop-blur hover:border-purple-500/60 transition-all cursor-pointer">
            <div className="text-4xl mb-3">📊</div>
            <h3 className="text-xl font-bold text-white mb-2">LEADERBOARD</h3>
            <p className="text-gray-300">Top Players</p>
          </Card>

          <Card className="p-6 bg-slate-800/50 border-purple-500/30 backdrop-blur hover:border-purple-500/60 transition-all cursor-pointer">
            <div className="text-4xl mb-3">⚙️</div>
            <h3 className="text-xl font-bold text-white mb-2">SETTINGS</h3>
            <p className="text-gray-300">Audio, Controls</p>
          </Card>
        </div>

        <div className="mt-8 p-4 bg-slate-800/50 border border-yellow-500/30 rounded-lg">
          <p className="text-yellow-400 text-sm font-semibold">📰 Breaking News</p>
          <p className="text-gray-300 text-sm mt-2">Solana network status: Operational | Gas fees: Normal</p>
        </div>
      </div>
    </div>
  );
};
